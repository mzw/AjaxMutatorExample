<div class="quizzy_load_body"><h1>Please Select a Quiz</h1>  		<p>
  		  <input type="radio" class="quizzy_quiz_opt" id="quizzy_quiz_opt0" onClick="quizFile = 'quiz.xml'; quizIndex = 0;" name="quizzy_quiz_sel">
        <label class="quizzy_quiz_lbl" id="quizzy_quiz_lbl0">About AjaxMutator</label>
                <br >
          <div id="quizzy_quiz_desc0" class="quizzy_quiz_desc">
            <img src="quizzy/quizzes/./logo.png" alt="" >            Several quizzes are available; min/max score range is 0-100.          </div>
                 </p>
  		<p>
  		  <input type="radio" class="quizzy_quiz_opt" id="quizzy_quiz_opt1" onClick="quizFile = 'quiz.xml'; quizIndex = 1;" name="quizzy_quiz_sel">
        <label class="quizzy_quiz_lbl" id="quizzy_quiz_lbl1">Another Quiz</label>
                <br >
          <div id="quizzy_quiz_desc1" class="quizzy_quiz_desc">
                        Under construction          </div>
                 </p>
</div>
    <div class="quizzy_load_foot"><input type="submit" class="quizzy_b" id="quizzy_start_b" value="Start Quiz"></div>
