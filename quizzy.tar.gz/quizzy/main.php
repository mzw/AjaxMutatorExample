<html>
<head>
<?php include 'quizzy/quizzyHeader.php';?> 
</head>
<body>
<img src="header.png" width="200px" />
<?php include 'quizzy/quizzy.php'; ?> 
</body>
</html>
